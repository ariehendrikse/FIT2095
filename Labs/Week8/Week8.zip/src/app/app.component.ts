import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  data = [];
  uid:number;
  make:string;
  model:string;
  bType:string;
  year:number;
  address:string;
  state:string;
  postcode:string='';
  states:string[]=['VIC','NSW','QLD','TAS','WA','ACT','NT','SA'];
  bTypes:string[]=['Bus', 'Coupe', 'Hatch', 'Sedan', 'SUV', 'Van', 'Ute'];
  newItem() {
      if (!this.pcInvalid()){
        this.data=this.data.filter(item=>item.uid!=this.uid);//gets rid of cars with same ID
        this.data.push({uid:this.uid,
        make:this.make,
        model:this.model,
        bType:this.bType,
        year:this.year,
        address:this.address,
        state:this.state,
        postcode:this.postcode});
      }
    }
  deleteOld(){
    console.log(this.data);
    this.data=this.data.filter(item=>item.year>2000)
  }
  numOld(){
    return this.data.filter(item=>item.year<2000).length;
  }
  clearItems() {
    this.data = [];
  }
  delete(u:string){
    this.data=this.data.filter(item=>item.uid!=u)
  }
  pcInvalid(){
    let postcodeRG= new RegExp('^(0[289][0-9]{2})|([1345689][0-9]{3})|(2[0-8][0-9]{2})|(290[0-9])|(291[0-4])|(7[0-4][0-9]{2})|(7[8-9][0-9]{2})$');
    return (!postcodeRG.test(this.postcode)&&this.postcode.length<4);
  }
}